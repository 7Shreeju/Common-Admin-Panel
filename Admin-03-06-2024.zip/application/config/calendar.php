<?php
  $config['client_id'] = 'xxxxxxxxxxxxxx.apps.googleusercontent.com';
  $config['client_secret'] = 'xxxxxxxxxxxxxx';
?>