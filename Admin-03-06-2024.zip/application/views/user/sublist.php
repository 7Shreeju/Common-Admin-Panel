
<div class="container-xxl flex-grow-1 container-p-y">
 

    <!-- Complex Headers -->
    <div class="card">
    <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="card-header p-0">Sub Admin List</h5>
        
        </div>

        <div class="table-responsive tbl-padding">
        <input type="hidden" id="url22" value="fetch-subadminlist">   
            <table  class="table table-striped" id="example">
                <thead>
                    <tr>
                        <th >
                            Sr No
                        </th>
                        <th>Name</th>

                        <th>Role</th>
                        <th>Current Status</th>
                        <th>Created Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>


            </table>
        </div>

    </div>
    </div>

</div>



<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>