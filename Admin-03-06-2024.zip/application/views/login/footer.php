<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/jquery/jquery.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/popper/popper.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/js/bootstrap.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/hammer/hammer.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/i18n/i18n.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/typeahead-js/typeahead.js"></script>

<script src="<?php base_url(); ?>template/admin_assets/vendor/js/menu.js"></script>
<!-- endbuild -->

<!-- Vendors JS -->
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js"></script>

<!-- Main JS -->
<script src="<?php base_url(); ?>template/admin_assets/js/main.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/vendor/libs/sweetalert2/sweetalert2.js"></script>
<script src="<?php base_url(); ?>template/admin_assets/extended-ui-sweetalert2.js"></script>

<!-- Page JS -->
<script src="<?php base_url(); ?>template/admin_assets/js/pages-auth.js"></script>
<script src="<?php echo base_url(); ?>template/custom/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>template/custom/js/login.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/toast/jquery.toast.js"></script>
