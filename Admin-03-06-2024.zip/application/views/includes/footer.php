
<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-center py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            Copyright © <script>
                document.write(new Date().getFullYear())
            </script>
          Common Admin Panel. All Rights Reserved. Powered By: <a href="https://www.digihost.in" target="_blank" class="footer-link fw-bolder" title="DigiHost Tech Solutions Pvt. Ltd">DigiHost Tech Solutions Pvt. Ltd.</a>
        </div>
    </div>
</footer>