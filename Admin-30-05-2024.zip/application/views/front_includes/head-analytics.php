<!-- 
<?php
if( $schemap !=""){

    echo $schemap;
}
else{

}

?>
 -->





<?php
if (isset($schemap)){
    echo $schemap;
}

else{


}
?>