
<div class="container-xxl flex-grow-1 container-p-y">





    <h4 class="fw-bold py-3 mb-4">

        Privileges

    </h4>

    <div class="row mb-4">
        <div class="col-md mb-4 mb-md-0">

            <div class="card">

                <div class="card-body">

                    <form class="privilege" method="post"  >
                        <!-- action="../add-privilege" -->

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-2">

                                    <label class="form-label" for="bs-validation-name"><b>FAQ's</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">FAQ Category</label>
                                    <input type="checkbox"  name="catf" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">FAQ Add</label>
                                    <input type="checkbox"  name="addf" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">FAQ List</label>
                                    <input type="checkbox"  name="listf" value="1">


                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="mb-2">

                                    <label class="form-label" for="bs-validation-upload-file"><b>Team</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Team add</label>
                                    <input type="checkbox"  name="addt" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Team List</label>
                                    <input type="checkbox"  name="listt" value="1">


                                </div>
                            </div>



                            <div class="col-md-4">
                                <div class="mb-3">

                                    <label class="form-label" for="bs-validation-upload-file"><b>Event</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Event category</label>
                                    <input type="checkbox"  name="cate" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Event add</label>
                                    <input type="checkbox"  name="adde" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Event List</label>
                                    <input type="checkbox"  name="liste" value="1">

                                </div> 
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Product</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Product category</label>
                                    <input type="checkbox"  name="catp" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Product Sub category</label>
                                    <input type="checkbox"  name="subcatp" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Product Add</label>
                                    <input type="checkbox"  name="addp" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Product List</label>
                                    <input type="checkbox"  name="listp" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Blog</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Add Author</label>
                                    <input type="checkbox" name="authb" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Auth List</label>
                                    <input type="checkbox"  name="authlistb" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Blog category</label>
                                    <input type="checkbox" name="catb" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Blog add</label>
                                    <input type="checkbox"  name="addb" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Blog List</label>
                                    <input type="checkbox"  name="listb" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Service</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Service category</label>
                                    <input type="checkbox"  name="cats" value="1">
                                    <br>
                                    <!--                        <label class="form-label" for="bs-validation-upload-file">Service Sub category</label>
                                                            <input type="checkbox"  name="subcats" value="1">
                                                            <br>-->
                                    <label class="form-label" for="bs-validation-upload-file">Service add</label>
                                    <input type="checkbox"  name="adds" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Service List</label>
                                    <input type="checkbox"  name="lists" value="1">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Jobs</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Jobs category</label>
                                    <input type="checkbox"  name="catj" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Jobs Add</label>
                                    <input type="checkbox"  name="addj" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Jobs List</label>
                                    <input type="checkbox"  name="listj" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>News</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">News category</label>
                                    <input type="checkbox" name="catn" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">News add</label>
                                    <input type="checkbox"  name="addn" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">News List</label>
                                    <input type="checkbox"  name="listn" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>List</b></label>
                                    <br>

                                    <label class="form-label" for="bs-validation-upload-file">Link List</label>
                                    <input type="checkbox"  name="listc" value="1">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Testimonial</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Testimonial Add</label>
                                    <input type="checkbox"  name="addtest" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Testimonial List</label>
                                    <input type="checkbox"  name="listest" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Client</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Client add</label>
                                    <input type="checkbox"  name="addct" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Client List</label>
                                    <input type="checkbox"  name="listct" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Video</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Video category</label>
                                    <input type="checkbox"  name="catv" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Video add</label>
                                    <input type="checkbox"  name="addv" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Video List</label>
                                    <input type="checkbox"  name="listv" value="1">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Pdf</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Pdf Add</label>
                                    <input type="checkbox"  name="addpd" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Pdf List</label>
                                    <input type="checkbox"  name="listpd" value="1">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Gallery</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Gallery category</label>
                                    <input type="checkbox"  name="catg" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Gallery add</label>
                                    <input type="checkbox"  name="addg" value="1">
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Gallery List</label>
                                    <input type="checkbox"  name="listg" value="1">
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Links</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Links List</label>
                                    <input type="checkbox"  name="linklis" value="1">
                                    <br>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="bs-validation-upload-file"><b>Users</b></label>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">User list</label>
                                    <input type="checkbox"  name="users" value="1" checked disabled>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Add Sub Admin</label>
                                    <input type="checkbox"  name="addusers" value="1" checked disabled>
                                    <br>
                                    <label class="form-label" for="bs-validation-upload-file">Sub Admin List</label>
                                    <input type="checkbox"  name="listusers" value="1" checked disabled>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-12">

                                <input type="hidden" name="id" value="<?php echo$this->session->userdata('sub'); ?>">

                                <button type="submit" id="add-pri"  class="btn btn-primary">Add</button>

                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>