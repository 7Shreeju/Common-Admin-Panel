
<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/popper/popper.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/hammer/hammer.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/i18n/i18n.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/typeahead-js/typeahead.js"></script>

<script src="<?php echo base_url(); ?>template/admin_assets/vendor/js/menu.js"></script>
<!-- endbuild -->

<!-- Vendors JS -->
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/jszip/jszip.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/pdfmake/pdfmake.js"></script>
<!-- Flat Picker -->
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/moment/moment.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/flatpickr/flatpickr.js"></script>
<!-- Row Group JS -->
<!-- Form Validation -->
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/jquery-timepicker/jquery-timepicker.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/pickr/pickr.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/js/datatables.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/js/datatables.js"></script>
<!-- Main JS -->
<script src="<?php echo base_url(); ?>template/admin_assets/js/main.js"></script>
<script src="<?php echo base_url(); ?>template/custom/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/toast/jquery.toast.js"></script>
<!-- Page JS -->


<script src="<?php echo base_url(); ?>template/custom/js/faq.js?v=6"></script>
<script src="<?php echo base_url(); ?>template/custom/js/product.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/clientele.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/login.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/profile.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/service.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/gallary.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/blog.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/job.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/event.js?v=6"></script>
<script src="<?php echo base_url(); ?>template/custom/js/news.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/testinomial.js?v=6"></script>
<script src="<?php echo base_url(); ?>template/custom/js/team.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/video.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/pdf.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/link.js?v=7"></script>
<script src="<?php echo base_url(); ?>template/custom/js/slider.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/adminsetup.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/common.js?v=5"></script>
<script src="<?php echo base_url(); ?>template/custom/js/datatable_fetch.js?v=6"></script>

<script src="<?php echo base_url(); ?>template/custom/js/project.js?v=6"></script>
<script src="<?php echo base_url(); ?>template/custom/js/list.js?v=5"></script>

<script src="<?php echo base_url(); ?>template/admin_assets/js/tables-datatables-basic.js"></script>

<script src="<?php echo base_url(); ?>template/admin_assets/js/main.js"></script>
<script src="<?php echo base_url(); ?>template/admin_assets/vendor/libs/sweetalert2/sweetalert2.js"></script>
